from setuptools import setup

setup(
    name='newpi',
    version='',
    packages=['talkback'],
    url='',
    license='',
    author='bai',
    author_email='lbai@temple.edu',
    description='',
    install_requires = [],
    package_data={'data': ['*.txt']}
)
